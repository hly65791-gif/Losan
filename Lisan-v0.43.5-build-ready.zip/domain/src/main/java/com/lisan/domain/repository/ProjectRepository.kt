package com.lisan.domain.repository

import com.lisan.domain.model.Project
import kotlinx.coroutines.flow.Flow

interface ProjectRepository {
    fun observeProjects(): Flow<List<Project>>
    suspend fun get(id: String): Project?
    suspend fun save(project: Project)
    suspend fun delete(id: String)
}
