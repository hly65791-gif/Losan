package com.lisan.domain.model

enum class SubtitleStylePreset(val wireName: String) {
    LISAN_CLASSIC("LISAN_CLASSIC"),
    CLEAN("CLEAN"),
    LARGE("LARGE")
}
