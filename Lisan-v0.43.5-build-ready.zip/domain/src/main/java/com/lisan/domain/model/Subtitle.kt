package com.lisan.domain.model

data class Subtitle(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
)

object SubtitleFormatter {
    fun toSrt(items: List<Subtitle>): String = items.joinToString("\n\n") {
        "${it.index}\n${timestamp(it.startMs, ',')} --> ${timestamp(it.endMs, ',')}\n${it.text.trim()}"
    } + if (items.isEmpty()) "" else "\n"

    fun toVtt(items: List<Subtitle>): String = buildString {
        append("WEBVTT\n\n")
        items.forEach {
            append("${timestamp(it.startMs, '.')} --> ${timestamp(it.endMs, '.')}\n")
            append(it.text.trim()).append("\n\n")
        }
    }

    private fun timestamp(ms: Long, separator: Char): String {
        val safe = ms.coerceAtLeast(0)
        val h = safe / 3_600_000
        val m = (safe % 3_600_000) / 60_000
        val s = (safe % 60_000) / 1_000
        val milli = safe % 1_000
        return "%02d:%02d:%02d%c%03d".format(h, m, s, separator, milli)
    }
}
