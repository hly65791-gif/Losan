package com.lisan.domain.usecase

import com.lisan.domain.model.Subtitle
import java.util.Locale

class SubtitleExportUseCase {
    fun toSrt(items: List<Subtitle>): String = items.joinToString("\n\n") { s ->
        "${s.index}\n${time(s.startMs)} --> ${time(s.endMs)}\n${s.text}"
    }

    fun toVtt(items: List<Subtitle>): String =
        "WEBVTT\n\n" + items.joinToString("\n\n") { s ->
            "${time(s.startMs)} --> ${time(s.endMs)}\n${s.text}"
        }

    private fun time(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        val sec = (ms % 60_000) / 1_000
        val milli = ms % 1_000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, sec, milli)
    }
}
