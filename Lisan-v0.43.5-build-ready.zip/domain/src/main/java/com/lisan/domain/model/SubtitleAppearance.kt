package com.lisan.domain.model

enum class SubtitlePosition(val alignment: Int, val label: String) {
    TOP(8, "أعلى"),
    CENTER(5, "وسط"),
    BOTTOM(2, "أسفل"),
    CUSTOM(5, "مخصص")
}

enum class SubtitleShape(val wireName: String, val label: String) {
    OUTLINE("OUTLINE", "حد أسود"),
    SHADOW("SHADOW", "ظل"),
    BOX("BOX", "مربع"),
    ROUNDED_BOX("ROUNDED_BOX", "مربع ناعم")
}

data class SubtitleAppearance(
    val fontSizeSp: Int = 54,
    val position: SubtitlePosition = SubtitlePosition.BOTTOM,
    val shape: SubtitleShape = SubtitleShape.OUTLINE,
    val outlineWidth: Int = 4,
    val shadowDepth: Int = 1,
    /** Safe-area position in percent of the 1920x1080 render canvas. */
    val horizontalPercent: Int = 50,
    val verticalPercent: Int = 88
) {
    val safeHorizontal: Int get() = horizontalPercent.coerceIn(8, 92)
    val safeVertical: Int get() = verticalPercent.coerceIn(8, 92)

    fun withPreset(value: SubtitlePosition): SubtitleAppearance = when (value) {
        SubtitlePosition.TOP -> copy(position = value, horizontalPercent = 50, verticalPercent = 14)
        SubtitlePosition.CENTER -> copy(position = value, horizontalPercent = 50, verticalPercent = 50)
        SubtitlePosition.BOTTOM -> copy(position = value, horizontalPercent = 50, verticalPercent = 88)
        SubtitlePosition.CUSTOM -> copy(position = value)
    }
}
