plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.lisan.core.common"; compileSdk = 35 }
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0") }
