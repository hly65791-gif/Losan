# v0.43.5 — Native Cloud Build Wrapper

- Added `gradle/wrapper/gradle-wrapper.jar` so ZIP build services that require the Wrapper JAR can recognize the project.
- Kept Gradle 8.10.2 distribution URL and SHA-256 pin.
- Replaced the previous cloud-only shell bootstrap with a Java bootstrap wrapper that downloads and verifies the pinned Gradle distribution before invoking it.
- This wrapper JAR is a Lisan cloud-build bootstrap and is **not** the official Gradle-published Wrapper JAR; use an official generated Wrapper JAR for long-term production source control.

# Lisan v0.43.4 — Cloud Build Bootstrap

- Added Gradle 8.10.2 cloud bootstrap scripts for ZIP-based builders that do not provide Gradle Wrapper files.
- Bootstrap verifies the official Gradle 8.10.2 binary SHA-256 before execution.
- Added `gradle/wrapper/gradle-wrapper.properties` with Gradle 8.10.2 distribution metadata.
- This is a temporary cloud-build bridge; a standard official Gradle Wrapper JAR should replace it when a Gradle-installed environment is available.

# v0.43.2

- Replaced deprecated FastAPI `@app.on_event("startup")` Redis initialization with lifespan handling.
- Backend test suite: 48/48 PASS with zero deprecation warnings.
- Python compileall: PASS.
- No Android build claim added: Gradle Wrapper and Android SDK remain required for APK/AAB validation.

## v0.43.1
- Reconciled backend reported version with the Android project release line.
- Added an accurate v0.43.1 project state and release TODO.
- Added BUILD_REPORT.md with actual environment and validation results.
- Confirmed backend regression suite: 48/48 passing.
- Kept Android release status explicitly blocked until Gradle Wrapper and Android SDK are available.

## v0.21.0 — Real render smoke test
- Added an end-to-end FFmpeg render test using a generated video + audio fixture.
- Verifies Arabic SRT burn-in, output dimensions, audio/video preservation, positive output size and backend validation.
- Added an independent ffprobe assertion so the smoke test validates the produced MP4 outside the backend parser.

## v0.18.0 — OCR styling and render controls
- OCR overlay typography controls: font size, outline, shadow, bold.
- Persisted OCR appearance settings and backend ASS overrides.
- Added bounded OCR render-style validation test.

## v0.16
- Added user-controlled Karaoke toggle in the subtitle editor.
- Live preview highlights the currently spoken translated word when valid alignment exists.
- RenderWorker only enables karaoke when the user explicitly enables it and alignment is present.
- Timeline remains word-aware and subtitle timing editable.

# Lisan Changelog

## v0.15.0
- Added real ASS karaoke rendering from validated translated word alignment.
- RenderWorker automatically sends `translated_word_alignment.json` when available.
- Backend exposes `karaoke_enabled` in render metadata.
- Added regression test for per-word `\k` timing tags.

# Changelog

## 0.10.0
- Added subtitle review gate before final burn-in.
- Added real subtitle editor using generated SRT.
- Added Media3 video preview with active subtitle overlay.
- Added font size, position, shape, outline and shadow controls.
- Added add/delete/edit subtitle segments and start/end timing controls.
- Added dedicated RenderWorker: edited SRT is rendered only after user confirmation.
- Added Room migration 5→6 for subtitle appearance settings.
- Backend ASS/libass rendering now accepts custom subtitle appearance parameters.
- Added backend tests for custom subtitle size/position/shape.

## 0.11.0
- Added professional subtitle timeline and seeking.
- Added segment shift and precise start/end editing.
- Added undo/redo history.
- Added safe-area draggable subtitle placement.
- Added custom normalized subtitle coordinates persisted through Room 6 → 7.
- Added ASS custom-position rendering and backend tests.

## 0.12.0
- Added subtitle Split and Merge.
- Added STT-timing-based Auto-Sync.
- Added editable OCR overlay list with enable/disable, text editing and draggable normalized position.
- Added OCR overlay JSON persistence and render transport.
- Added backend OCR box coordinate extraction and ASS overlay burn-in.
- Preview uses a 16:9 FIT canvas aligned with the render coordinate system.

## v0.14
- Added a real bilingual alignment contract via `/v1/align` with strict validation.
- Added Android alignment client and editor action `محاذاة الكلمات`.
- Alignment output is persisted as `translated_word_alignment.json` and shown as word timing markers.
- No fake alignment: backend returns `501 ALIGNMENT_PROVIDER_NOT_CONFIGURED` until a real alignment service is configured.


## v0.17.0
- Added real horizontal timeline scrolling for zoom levels up to 6×.
- Added playback-following playhead auto-scroll.
- Separated translated alignment loading from source Whisper word timestamps.
- Invalidated translated word alignment after subtitle edits to prevent stale Karaoke timing.
- Kept PCM waveform extraction and documented the fallback behavior.

## v0.25.0 — Durable end-to-end pipeline jobs
- Added `/v1/pipeline` for asynchronous Upload → Audio Extraction → STT → Translation → OCR → Alignment → SRT → Render orchestration.
- Persisted pipeline checkpoints to `pipeline-<job_id>/job.json` so completed stages are not repeated after process interruption.
- Added `/v1/pipeline-jobs/{job_id}` status endpoint and `/resume` endpoint.
- Pipeline stores transcript, translation, OCR, alignment and SRT artifacts on disk.
- Final render still passes through the existing strict render validation gate.
- Added Android `LisanBackendClient` methods for starting, polling and resuming pipeline jobs.
- Backend version bumped to 0.25.0.


## v0.26.0
- Added optional Redis Streams distributed job queue for pipeline and async render jobs.
- Added queue health reporting and worker startup.
- Added serializable job payloads for multi-instance workers.
- Kept in-process fallback for development.

## v0.27.0
- Added local/GCS/S3 object-storage abstraction.
- Completed uploads are promoted to object storage in production mode.
- Workers can restore missing local upload files from object storage.
- Render artifacts can be persisted to object storage.
- Added storage health endpoint and production storage documentation.

## v0.36
- Added optional Arabic UI control for "ترجمة شاملة".
- Added optional "استبدال النص الأصلي" for OCR text when comprehensive translation is enabled.
- Persisted both settings in Room (migration 7→8).
- OCR artifacts inherit replacement and motion-tracking settings.

## v0.43.0
- Release hardening pass.
- Android versionCode 43 / versionName 0.43.0.
- Release builds disable cleartext HTTP; debug builds retain cleartext for local development.
- Added release gate and hardening documentation.
- Backend tests: 48/48 PASS.
- APK/AAB remain blocked until Gradle Wrapper and Android SDK are available.
