package com.lisan.data

import com.lisan.data.db.ProjectDao
import com.lisan.data.db.ProjectEntity
import com.lisan.domain.model.Project
import com.lisan.domain.model.ProjectStatus
import com.lisan.domain.model.SubtitleStylePreset
import com.lisan.domain.model.SubtitleAppearance
import com.lisan.domain.model.SubtitlePosition
import com.lisan.domain.model.SubtitleShape
import com.lisan.domain.repository.ProjectRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import javax.inject.Inject

class ProjectRepositoryImpl @Inject constructor(
    private val dao: ProjectDao
) : ProjectRepository {
    override fun observeProjects(): Flow<List<Project>> = dao.observeAll().map { list -> list.map(::toDomain) }
    override suspend fun get(id: String): Project? = dao.get(id)?.let(::toDomain)
    override suspend fun save(project: Project) = dao.upsert(toEntity(project))
    override suspend fun delete(id: String) = dao.delete(id)

    private fun toEntity(p: Project) = ProjectEntity(
        p.id, p.name, p.sourceUri, p.sourceLanguage, p.targetLanguage,
        p.status.name, p.progress, p.createdAt.toEpochMilli(), p.updatedAt.toEpochMilli(), p.error, p.outputPath, p.artifactId, p.subtitleStyle.wireName, p.subtitleAppearance.fontSizeSp, p.subtitleAppearance.position.name, p.subtitleAppearance.shape.wireName, p.subtitleAppearance.outlineWidth, p.subtitleAppearance.shadowDepth, p.subtitleAppearance.safeHorizontal, p.subtitleAppearance.safeVertical, p.comprehensiveTranslation, p.replaceOcrText
    )

    private fun toDomain(e: ProjectEntity) = Project(
        e.id, e.name, e.sourceUri, e.sourceLanguage, e.targetLanguage,
        runCatching { ProjectStatus.valueOf(e.status) }.getOrDefault(ProjectStatus.DRAFT),
        e.progress, Instant.ofEpochMilli(e.createdAt), Instant.ofEpochMilli(e.updatedAt), e.error, e.outputPath, e.artifactId, runCatching { SubtitleStylePreset.valueOf(e.subtitleStyle) }.getOrDefault(SubtitleStylePreset.LISAN_CLASSIC), SubtitleAppearance(e.subtitleFontSize, runCatching { SubtitlePosition.valueOf(e.subtitlePosition) }.getOrDefault(SubtitlePosition.BOTTOM), runCatching { SubtitleShape.valueOf(e.subtitleShape) }.getOrDefault(SubtitleShape.OUTLINE), e.subtitleOutlineWidth, e.subtitleShadowDepth, e.subtitleHorizontalPercent, e.subtitleVerticalPercent), e.comprehensiveTranslation, e.replaceOcrText
    )
}
