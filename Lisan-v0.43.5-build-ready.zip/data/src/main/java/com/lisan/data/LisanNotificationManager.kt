package com.lisan.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ForegroundInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LisanNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val CHANNEL_ID = "lisan_processing"
        const val CHANNEL_NAME = "Lisan processing"
        const val NOTIFICATION_ID = 2407
    }

    init { createChannel() }

    private fun createChannel() {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW).apply {
                description = "Video translation progress and completion"
                setShowBadge(true)
            }
        )
    }

    fun foregroundInfo(projectName: String, progress: Int, message: String): ForegroundInfo {
        val notification = builder(projectName, progress, message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        return if (android.os.Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    fun started(projectName: String, resumed: Boolean) {
        notify(projectName, if (resumed) "تم استئناف الترجمة" else "بدأت ترجمة الفيديو", 0, true)
    }

    fun reviewRequired(projectName: String) {
        notify(projectName, "الترجمة جاهزة للمراجعة — عدّل النص والتوقيت والشكل قبل الحرق", 82, false)
    }

    fun completed(projectName: String) {
        notify(projectName, "اكتملت الترجمة بنجاح", 100, false)
    }

    fun failed(projectName: String, message: String) {
        notify(projectName, "توقفت الترجمة: $message", 0, false)
    }

    fun waitingForNetwork(projectName: String) {
        notify(projectName, "انقطع الإنترنت — سيتم الاستئناف تلقائيًا عند عودته", 0, true)
    }

    private fun notify(projectName: String, message: String, progress: Int, ongoing: Boolean) {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return
        val notification = builder(projectName, progress, message)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setOnlyAlertOnce(true)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
    }

    private fun builder(projectName: String, progress: Int, message: String): NotificationCompat.Builder {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        } ?: Intent().setPackage(context.packageName)
        val pending = PendingIntent.getActivity(
            context, 2407, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.lisan.data.R.drawable.ic_lisan_notification)
            .setContentTitle("لسان • $projectName")
            .setContentText(message)
            .setContentIntent(pending)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(100, progress.coerceIn(0, 100), progress <= 0)
    }
}
