package com.lisan.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ProjectEntity::class, ProcessingJobEntity::class], version = 8, exportSchema = false)
abstract class LisanDatabase : RoomDatabase() {
    companion object {
        val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN outputPath TEXT")
                db.execSQL("ALTER TABLE projects ADD COLUMN artifactId TEXT")
            }
        }
        val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE processing_jobs ADD COLUMN uploadId TEXT")
            }
        }
        val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleStyle TEXT NOT NULL DEFAULT 'LISAN_CLASSIC'")
            }
        }
        val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleFontSize INTEGER NOT NULL DEFAULT 54")
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitlePosition TEXT NOT NULL DEFAULT 'BOTTOM'")
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleShape TEXT NOT NULL DEFAULT 'OUTLINE'")
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleOutlineWidth INTEGER NOT NULL DEFAULT 4")
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleShadowDepth INTEGER NOT NULL DEFAULT 1")
            }
        }
        val MIGRATION_6_7 = object : androidx.room.migration.Migration(6, 7) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleHorizontalPercent INTEGER NOT NULL DEFAULT 50")
                db.execSQL("ALTER TABLE projects ADD COLUMN subtitleVerticalPercent INTEGER NOT NULL DEFAULT 88")
            }
        }
        val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE projects ADD COLUMN comprehensiveTranslation INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE projects ADD COLUMN replaceOcrText INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
    abstract fun projectDao(): ProjectDao
    abstract fun processingJobDao(): ProcessingJobDao
}
