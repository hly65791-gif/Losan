package com.lisan.data

import android.content.Context
import android.net.Uri
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.lisan.data.db.ProcessingJobDao
import com.lisan.data.db.ProcessingJobEntity
import com.lisan.domain.model.ProcessingStage
import com.lisan.domain.model.ProjectStatus
import com.lisan.domain.model.Subtitle
import com.lisan.domain.model.SubtitleFormatter
import com.lisan.domain.provider.OcrProvider
import com.lisan.domain.provider.SpeechToTextProvider
import com.lisan.domain.provider.TranslationProvider
import com.lisan.domain.repository.ProjectRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

@HiltWorker
class ProcessingWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val jobs: ProcessingJobDao,
    private val projects: ProjectRepository,
    private val stt: SpeechToTextProvider,
    private val translation: TranslationProvider,
    private val ocr: OcrProvider,
    private val backend: LisanBackendClient,
    private val notifications: LisanNotificationManager
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val projectId = inputData.getString("projectId") ?: return Result.failure(errorData("MISSING_PROJECT_ID"))
        val sourceUri = inputData.getString("sourceUri") ?: return Result.failure(errorData("MISSING_SOURCE_URI"))
        val project = projects.get(projectId) ?: return Result.failure(errorData("PROJECT_NOT_FOUND"))

        val previousJob = jobs.get(projectId)
        val resumed = runAttemptCount > 0 || previousJob?.uploadId != null
        val projectName = project.name
        try {
            setForeground(notifications.foregroundInfo(projectName, 1, if (resumed) "استئناف الترجمة في الخلفية…" else "بدأت الترجمة في الخلفية…"))
            notifications.started(projectName, resumed)
            val root = File(applicationContext.filesDir, "processing/$projectId").apply { mkdirs() }
            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 5, updatedAt = Instant.now()), ProcessingStage.PREPARING, 5)

            val audioFile = File(root, "audio.m4a")
            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 15, updatedAt = Instant.now()), ProcessingStage.EXTRACTING_AUDIO, 15)
            AudioExtractor(applicationContext.contentResolver).extract(Uri.parse(sourceUri), audioFile)
            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 25, updatedAt = Instant.now()), ProcessingStage.EXTRACTING_AUDIO, 25)

            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 35, updatedAt = Instant.now()), ProcessingStage.TRANSCRIBING, 35)
            val transcript = stt.transcribe(audioFile.absolutePath, project.sourceLanguage)
            require(transcript.isNotEmpty()) { "STT_EMPTY_TRANSCRIPT" }

            val transcriptFile = File(root, "transcript.json")
            val transcriptJson = JSONArray().apply {
                transcript.forEach { item ->
                    put(JSONObject().apply {
                        put("start_ms", item.startMs)
                        put("end_ms", item.endMs)
                        put("text", item.text)
                        item.confidence?.let { put("confidence", it) }
                        put("words", JSONArray().apply { item.words.forEach { word -> put(JSONObject().apply { put("start_ms", word.startMs); put("end_ms", word.endMs); put("text", word.text); word.confidence?.let { put("confidence", it) } }) } })
                    })
                }
            }
            transcriptFile.writeText(transcriptJson.toString())

            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 55, updatedAt = Instant.now()), ProcessingStage.TRANSLATING, 55)
            val translated = translation.translate(transcript, project.sourceLanguage, project.targetLanguage)
            require(translated.isNotEmpty()) { "TRANSLATION_EMPTY" }

            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 68, updatedAt = Instant.now()), ProcessingStage.OCR_PROCESSING, 68)
            val ocrSegments = if (project.comprehensiveTranslation) {
                runCatching { ocr.detect(sourceUri, project.targetLanguage) }.getOrElse { emptyList() }
            } else {
                emptyList()
            }

            update(projectId, project.copy(status = ProjectStatus.PROCESSING, progress = 78, updatedAt = Instant.now()), ProcessingStage.GENERATING_SUBTITLES, 78)
            val subtitles = translated.mapIndexed { index, s -> Subtitle(index + 1, s.startMs, s.endMs, s.text) }
            val srtFile = File(root, "translated.srt")
            val vttFile = File(root, "translated.vtt")
            srtFile.writeText(SubtitleFormatter.toSrt(subtitles))
            vttFile.writeText(SubtitleFormatter.toVtt(subtitles))
            File(root, "ocr.txt").writeText(ocrSegments.joinToString("\n") { "${it.startMs}|${it.endMs}|${it.text}" })
            val ocrJson = JSONArray().apply {
                ocrSegments.forEachIndexed { index, item ->
                    put(JSONObject().apply {
                        put("id", index + 1)
                        put("start_ms", item.startMs)
                        put("end_ms", item.endMs)
                        put("text", item.text)
                        put("x_percent", item.x ?: 50)
                        put("y_percent", item.y ?: 50)
                        put("enabled", true)
                        put("replace_original", project.replaceOcrText && project.comprehensiveTranslation)
                        put("motion_tracking_enabled", project.comprehensiveTranslation)
                    })
                }
            }
            File(root, "ocr_overlays.json").writeText(ocrJson.toString())

            update(projectId, project.copy(status = ProjectStatus.PAUSED, progress = 82, updatedAt = Instant.now(), error = null), ProcessingStage.AWAITING_EDIT, 82)
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.AWAITING_EDIT.name, 82, System.currentTimeMillis(), "Subtitle editor ready"))
            notifications.reviewRequired(projectName)
            return Result.success(workDataOf(
                "projectId" to projectId,
                "stage" to ProcessingStage.AWAITING_EDIT.name,
                "progress" to 82,
                "srtPath" to srtFile.absolutePath,
                "vttPath" to vttFile.absolutePath,
                "awaitingSubtitleEdit" to true
            ))
        } catch (t: Throwable) {
            val message = t.message ?: t::class.java.simpleName
            if (isRetryable(t)) {
                projects.save(project.copy(status = ProjectStatus.PROCESSING, updatedAt = Instant.now(), error = "WAITING_FOR_NETWORK"))
                jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.RENDERING.name, project.progress, System.currentTimeMillis(), "Waiting for network", previousJob?.uploadId))
                notifications.waitingForNetwork(projectName)
                return Result.retry()
            }
            projects.save(project.copy(status = ProjectStatus.FAILED, updatedAt = Instant.now(), error = message))
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.FAILED.name, 0, System.currentTimeMillis(), message))
            notifications.failed(projectName, message)
            Result.failure(errorData("PROCESSING_FAILED", message))
        }
    }

    private suspend fun update(projectId: String, project: com.lisan.domain.model.Project, stage: ProcessingStage, progress: Int) {
        projects.save(project)
        setForeground(notifications.foregroundInfo(project.name, progress, stageMessage(stage, progress)))
        val existingUploadId = jobs.get(projectId)?.uploadId
        jobs.upsert(ProcessingJobEntity(projectId, stage.name, progress, System.currentTimeMillis(), uploadId = existingUploadId))
        setProgress(workDataOf("projectId" to projectId, "stage" to stage.name, "progress" to progress))
    }

    private fun stageMessage(stage: ProcessingStage, progress: Int): String = when (stage) {
        ProcessingStage.PREPARING -> "تحضير الفيديو…"
        ProcessingStage.EXTRACTING_AUDIO -> "استخراج الصوت…"
        ProcessingStage.TRANSCRIBING -> "تحويل الكلام إلى نص…"
        ProcessingStage.TRANSLATING -> "ترجمة النص…"
        ProcessingStage.OCR_PROCESSING -> "قراءة النصوص داخل الفيديو…"
        ProcessingStage.GENERATING_SUBTITLES -> "إنشاء الترجمة…"
        ProcessingStage.RENDERING -> "حرق الترجمة داخل الفيديو…"
        ProcessingStage.VALIDATING -> "التحقق من الفيديو النهائي…"
        ProcessingStage.COMPLETED -> "اكتملت الترجمة"
        ProcessingStage.FAILED -> "فشلت المعالجة"
    }

    private fun isRetryable(t: Throwable): Boolean {
        if (t is IOException || t is SocketTimeoutException || t is UnknownHostException) return true
        val m = t.message.orEmpty()
        return Regex("BACKEND_(408|425|429|5\\d{2})").containsMatchIn(m)
    }

    private fun errorData(code: String, message: String = code) =
        workDataOf("errorCode" to code, "errorMessage" to message)
}
