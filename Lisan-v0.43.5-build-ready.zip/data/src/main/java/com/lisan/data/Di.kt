package com.lisan.data

import android.content.Context
import androidx.room.Room
import com.lisan.data.db.LisanDatabase
import com.lisan.data.db.ProjectDao
import com.lisan.domain.repository.ProjectRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import com.lisan.domain.provider.SpeechToTextProvider
import com.lisan.domain.provider.TranslationProvider
import com.lisan.domain.provider.OcrProvider

@Module
@InstallIn(SingletonComponent::class)
object DataModule {
    @Provides @Singleton
    fun database(@ApplicationContext context: Context): LisanDatabase =
        Room.databaseBuilder(context, LisanDatabase::class.java, "lisan.db").addMigrations(LisanDatabase.MIGRATION_2_3, LisanDatabase.MIGRATION_3_4, LisanDatabase.MIGRATION_4_5, LisanDatabase.MIGRATION_5_6, LisanDatabase.MIGRATION_6_7, LisanDatabase.MIGRATION_7_8).build()

    @Provides
    fun projectDao(db: LisanDatabase): ProjectDao = db.projectDao()

    @Provides
    fun processingJobDao(db: LisanDatabase): com.lisan.data.db.ProcessingJobDao = db.processingJobDao()

    @Provides @Singleton
    fun projectRepository(dao: ProjectDao): ProjectRepository = ProjectRepositoryImpl(dao)

    @Provides @Singleton
    fun speechToTextProvider(api: LisanBackendClient): SpeechToTextProvider = BackendSpeechToTextProvider(api)

    @Provides @Singleton
    fun translationProvider(api: LisanBackendClient): TranslationProvider = BackendTranslationProvider(api)

    @Provides @Singleton
    fun ocrProvider(api: LisanBackendClient, @ApplicationContext context: Context): OcrProvider = BackendOcrProvider(api, context)
}

