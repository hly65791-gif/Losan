package com.lisan.feature.video

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri

data class VideoInfo(
    val durationMs: Long,
    val width: Int?,
    val height: Int?,
    val mimeType: String?
)

class VideoInspector(private val context: Context) {
    fun inspect(uri: Uri): VideoInfo? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            VideoInfo(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull(),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull(),
                context.contentResolver.getType(uri)
            )
        } catch (_: Exception) { null } finally { r.release() }
    }
}
