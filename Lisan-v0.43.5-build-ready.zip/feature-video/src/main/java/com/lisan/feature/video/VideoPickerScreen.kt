package com.lisan.feature.video

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.lisan.data.ProcessingWorker
import com.lisan.domain.model.Project
import com.lisan.domain.model.ProjectStatus
import com.lisan.domain.model.SubtitleStylePreset
import com.lisan.domain.repository.ProjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

private val Navy = Color(0xFF061126)
private val Surface = Color(0xFF0D1B38)
private val Purple = Color(0xFF8B4DFF)
private val Cyan = Color(0xFF12C8EE)
private val TextPrimary = Color(0xFFF7F8FF)
private val TextMuted = Color(0xFF9BA9C7)

private data class LanguageOption(val code: String, val label: String)
private val Languages = listOf(
    LanguageOption("auto", "اكتشاف تلقائي"), LanguageOption("ar", "العربية"),
    LanguageOption("en", "الإنجليزية"), LanguageOption("hi", "الهندية"),
    LanguageOption("ur", "الأوردية"), LanguageOption("bn", "البنغالية"),
    LanguageOption("tr", "التركية"), LanguageOption("fa", "الفارسية"),
    LanguageOption("ko", "الكورية"), LanguageOption("zh", "الصينية"),
    LanguageOption("id", "الإندونيسية"), LanguageOption("th", "التايلاندية"),
    LanguageOption("vi", "الفيتنامية")
)

@HiltViewModel
class VideoPickerViewModel @Inject constructor(private val repository: ProjectRepository) : ViewModel() {
    var selectedUri by mutableStateOf<Uri?>(null); private set
    var name by mutableStateOf("")
    var sourceLanguage by mutableStateOf("auto")
    var targetLanguage by mutableStateOf("ar")
    var subtitleStyle by mutableStateOf(SubtitleStylePreset.LISAN_CLASSIC)
    var comprehensiveTranslation by mutableStateOf(false)
    var replaceOcrText by mutableStateOf(false)
    var error by mutableStateOf<String?>(null); private set

    fun select(uri: Uri) { selectedUri = uri; if (name.isBlank()) name = "ترجمة جديدة"; error = null }
    fun start(workManager: WorkManager, durationMs: Long) {
        val uri = selectedUri ?: return
        if (durationMs <= 0L) { error = "تعذر قراءة مدة الفيديو."; return }
        if (durationMs > 4 * 60 * 60 * 1000L) { error = "مدة الفيديو تتجاوز الحد الحالي وهو 4 ساعات."; return }
        if (sourceLanguage == targetLanguage && sourceLanguage != "auto") { error = "اختر لغة ترجمة مختلفة عن لغة الفيديو."; return }
        viewModelScope.launch {
            val id = UUID.randomUUID().toString()
            repository.save(Project(id, name.ifBlank { "ترجمة جديدة" }, uri.toString(), sourceLanguage, targetLanguage,
                ProjectStatus.QUEUED, subtitleStyle = subtitleStyle,
                comprehensiveTranslation = comprehensiveTranslation,
                replaceOcrText = comprehensiveTranslation && replaceOcrText))
            val request = OneTimeWorkRequestBuilder<ProcessingWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInputData(workDataOf("projectId" to id, "sourceUri" to uri.toString()))
                .build()
            workManager.enqueueUniqueWork("lisan_$id", ExistingWorkPolicy.KEEP, request)
        }
    }
}

@Composable
fun VideoPickerScreen(onBack: () -> Unit, onStarted: () -> Unit = {}, vm: VideoPickerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val workManager = remember { WorkManager.getInstance(context) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var thumbnail by remember { mutableStateOf<Bitmap?>(null) }
    var showSource by remember { mutableStateOf(false) }
    var showTarget by remember { mutableStateOf(false) }
    var showStyle by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.select(it)
            videoInfo = VideoInspector(context).inspect(it)
            thumbnail = loadThumbnail(context, it)
        }
    }

    val info = videoInfo
    val duration = info?.durationMs ?: 0L
    val canStart = vm.selectedUri != null && duration > 0L && duration <= 4 * 60 * 60 * 1000L

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = { Text("ترجمة فيديو", color = TextPrimary, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = TextPrimary) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
            )
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp, 8.dp, 18.dp, 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    if (vm.selectedUri == null) {
                        EmptyVideoCard { launcher.launch(arrayOf("video/*")) }
                    } else {
                        VideoPreviewCard(thumbnail, info) { launcher.launch(arrayOf("video/*")) }
                    }
                }
                item {
                    OutlinedTextField(vm.name, { vm.name = it }, label = { Text("اسم المشروع") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), colors = outlinedColors())
                }
                item {
                    LanguageCard("لغة الفيديو", Languages.first { it.code == vm.sourceLanguage }.label, { showSource = true })
                    Spacer(Modifier.height(8.dp))
                    LanguageCard("لغة الترجمة", Languages.first { it.code == vm.targetLanguage }.label, { showTarget = true })
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Translate, null, tint = Cyan)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("ترجمة شاملة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Text("الصوت + اللافتات + الرسائل + أسماء المحلات + النصوص الظاهرة", color = TextMuted, fontSize = 12.sp)
                                }
                                Switch(vm.comprehensiveTranslation, { vm.comprehensiveTranslation = it; if (!it) vm.replaceOcrText = false })
                            }
                            if (vm.comprehensiveTranslation) {
                                HorizontalDivider(color = Color.White.copy(.08f))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ClosedCaption, null, tint = Purple)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("استبدال النص الأصلي", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                        Text("يغطي النص الأصلي ويضع الترجمة في موقعه قدر الإمكان.", color = TextMuted, fontSize = 12.sp)
                                    }
                                    Switch(vm.replaceOcrText, { vm.replaceOcrText = it })
                                }
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                        TextButton(onClick = { showStyle = true }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text("شكل الترجمة", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text("Lisan Classic • أبيض عريض + حدود سوداء", color = TextMuted, fontSize = 12.sp)
                                }
                                Text("تغيير", color = Cyan)
                            }
                        }
                    }
                }
                info?.let { v ->
                    item {
                        val seconds = v.durationMs / 1000
                        val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
                        Text("${if (h > 0) "$h ساعة " else ""}${m} دقيقة ${s} ثانية  •  ${v.width ?: "?"}×${v.height ?: "?"}", color = TextMuted, fontSize = 12.sp)
                    }
                }
                vm.error?.let { msg -> item { Text(msg, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) } }
                item {
                    Button(
                        onClick = { vm.start(workManager, info?.durationMs ?: 0L); onStarted() }, enabled = canStart,
                        modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("ابدأ الترجمة", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showSource) LanguageDialog("اختر لغة الفيديو", Languages, vm.sourceLanguage, { showSource = false }) { vm.sourceLanguage = it; showSource = false }
    if (showTarget) LanguageDialog("اختر لغة الترجمة", Languages.filter { it.code != "auto" }, vm.targetLanguage, { showTarget = false }) { vm.targetLanguage = it; showTarget = false }
    if (showStyle) StyleDialog(vm.subtitleStyle, { showStyle = false }) { vm.subtitleStyle = it; showStyle = false }
}

@Composable private fun EmptyVideoCard(onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().height(210.dp), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Purple.copy(.25f), Cyan.copy(.12f)))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.VideoFile, null, tint = Cyan, modifier = Modifier.size(52.dp))
                Text("اختر فيديو للبدء", color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("MP4 • MOV • MKV وغيرها حسب دعم الجهاز", color = TextMuted, fontSize = 12.sp)
                Text("اضغط هنا لاختيار الفيديو", color = Cyan, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun VideoPreviewCard(bitmap: Bitmap?, info: VideoInfo?, onChange: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(10.dp)) {
            if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black), contentAlignment = Alignment.Center) { Icon(Icons.Default.VideoFile, null, tint = TextMuted, modifier = Modifier.size(48.dp)) }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Cyan)
                Spacer(Modifier.width(7.dp))
                Text("الفيديو جاهز", color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onChange) { Text("تغيير") }
            }
        }
    }
}

@Composable private fun LanguageCard(title: String, value: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Translate, null, tint = Cyan); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(title, color = TextMuted, fontSize = 12.sp); Text(value, color = TextPrimary, fontWeight = FontWeight.Bold) }
            Text("تغيير", color = Cyan)
        }
    }
}

@Composable private fun LanguageDialog(title: String, options: List<LanguageOption>, selected: String, onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    Dialog(onDismissRequest = onDismiss) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(24.dp)) { LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp).padding(10.dp)) { item { Text(title, color = TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp)) }; items(options.size) { i -> val o = options[i]; TextButton(onClick = { onSelect(o.code) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(o.label, color = TextPrimary, modifier = Modifier.weight(1f)); if (o.code == selected) Icon(Icons.Default.CheckCircle, null, tint = Cyan) } } } } } }
}

@Composable private fun StyleDialog(selected: SubtitleStylePreset, onDismiss: () -> Unit, onSelect: (SubtitleStylePreset) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("شكل الترجمة") }, text = { Column { SubtitleStylePreset.entries.forEach { s -> TextButton(onClick = { onSelect(s) }, modifier = Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth()) { Text(s.name.replace('_', ' '), modifier = Modifier.weight(1f)); if (s == selected) Icon(Icons.Default.CheckCircle, null, tint = Cyan) } } } } }, confirmButton = {})
}

@Composable private fun outlinedColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color.White.copy(.15f), focusedLabelColor = Cyan, unfocusedLabelColor = TextMuted, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)

private fun loadThumbnail(context: android.content.Context, uri: Uri): Bitmap? = runCatching {
    MediaMetadataRetriever().use { r -> r.setDataSource(context, uri); r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) }
}.getOrNull()
