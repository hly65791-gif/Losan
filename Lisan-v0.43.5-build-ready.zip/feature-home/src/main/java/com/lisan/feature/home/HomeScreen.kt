package com.lisan.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.hilt.navigation.compose.hiltViewModel
import com.lisan.domain.model.Project
import com.lisan.domain.model.ProjectStatus
import androidx.compose.runtime.CompositionLocalProvider
import com.lisan.ui.R

private val LisanNavy = Color(0xFF061126)
private val LisanSurface = Color(0xFF0D1B38)
private val LisanSurface2 = Color(0xFF12244A)
private val LisanPurple = Color(0xFF8B4DFF)
private val LisanCyan = Color(0xFF12C8EE)
private val LisanText = Color(0xFFF7F8FF)
private val LisanMuted = Color(0xFF9BA9C7)

@Composable
fun HomeScreen(
    onTranslate: () -> Unit,
    onProjects: () -> Unit,
    onSettings: () -> Unit,
    vm: HomeViewModel = hiltViewModel()
) {
    val projects by vm.recentProjects.collectAsState()
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = LisanNavy,
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xFF07142B),
                    tonalElevation = 0.dp
                ) {
                    NavigationBarItem(
                        selected = true,
                        onClick = { },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("الرئيسية") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = onProjects,
                        icon = { Icon(Icons.Default.Folder, null) },
                        label = { Text("مشاريعي") }
                    )
                    Spacer(Modifier.width(52.dp))
                    NavigationBarItem(
                        selected = false,
                        onClick = { },
                        icon = { Icon(Icons.Default.Translate, null) },
                        label = { Text("اكتشف") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = onSettings,
                        icon = { Icon(Icons.Default.Person, null) },
                        label = { Text("حسابي") }
                    )
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Spacer(Modifier.height(12.dp))
                    TopBar(onSettings)
                    HeroCard(onTranslate)
                    QuickActions(onProjects, onSettings)
                    RecentSection(projects = projects.take(3), onProjects = onProjects)
                    Spacer(Modifier.height(8.dp))
                }

                FloatingActionButton(
                    onClick = onTranslate,
                    modifier = Modifier.align(Alignment.BottomCenter).offset(y = (-10).dp),
                    containerColor = LisanPurple,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = "مشروع جديد")
                }
            }
        }
    }
}

@Composable
private fun TopBar(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(LisanSurface2),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.ic_lisan_logo),
                    contentDescription = "شعار لسان",
                    modifier = Modifier.size(38.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("لسان", color = LisanText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("ترجم. افهم. شاهد.", color = LisanMuted, fontSize = 12.sp)
            }
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, "الإعدادات", tint = LisanText)
        }
    }
}

@Composable
private fun HeroCard(onTranslate: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF5C28D9), Color(0xFF157DDB), Color(0xFF10BBD9))))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = .16f)
                ) {
                    Text("ترجمة شاملة", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                }
                Text("ترجم الفيديو بكل تفاصيله", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "الصوت والنصوص الظاهرة داخل المشهد، مثل اللافتات والرسائل وأسماء المحلات.",
                    color = Color.White.copy(alpha = .9f),
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )
                Button(
                    onClick = onTranslate,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF5C28D9))
                ) {
                    Icon(Icons.Default.VideoLibrary, null)
                    Spacer(Modifier.width(8.dp))
                    Text("اختر فيديو", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun QuickActions(onProjects: () -> Unit, onSettings: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الوصول السريع", color = LisanText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("مشاريعي", "ترجماتك السابقة", Icons.Default.Folder, onProjects, Modifier.weight(1f))
            QuickAction("السحابة", "ملفاتك المحفوظة", Icons.Default.Cloud, {}, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction("الإعدادات", "تخصيص التطبيق", Icons.Default.Settings, onSettings, Modifier.weight(1f))
            QuickAction("الدعم", "مساعدة وملاحظات", Icons.Default.SupportAgent, {}, Modifier.weight(1f))
        }
    }
}

@Composable
private fun QuickAction(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LisanSurface)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = LisanCyan, modifier = Modifier.size(25.dp))
            Text(title, color = LisanText, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = LisanMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun RecentSection(projects: List<Project>, onProjects: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("المشاريع الأخيرة", color = LisanText, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onProjects) { Text("عرض الكل", color = LisanCyan) }
        }

        if (projects.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onTranslate),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = LisanSurface)
            ) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(LisanPurple, LisanCyan))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ابدأ أول ترجمة لك", color = LisanText, fontWeight = FontWeight.Bold)
                        Text("اختر فيديو وسيظهر مشروعك هنا", color = LisanMuted, fontSize = 12.sp)
                    }
                }
            }
        } else {
            projects.forEach { project ->
                RecentProjectCard(project = project, onClick = onProjects)
            }
        }
    }
}

@Composable
private fun RecentProjectCard(project: Project, onClick: () -> Unit) {
    val statusText = when (project.status) {
        ProjectStatus.COMPLETED -> "مكتمل"
        ProjectStatus.PROCESSING -> "جاري المعالجة"
        ProjectStatus.QUEUED -> "في الانتظار"
        ProjectStatus.PAUSED -> "متوقف مؤقتًا"
        ProjectStatus.FAILED -> "فشل"
        ProjectStatus.CANCELLED -> "ملغى"
        ProjectStatus.DRAFT -> "مسودة"
    }
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = LisanSurface)
    ) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(LisanPurple, LisanCyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(project.name, color = LisanText, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("${project.sourceLanguage}  →  ${project.targetLanguage}", color = LisanMuted, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Surface(shape = RoundedCornerShape(50), color = LisanPurple.copy(alpha = .18f)) {
                        Text(statusText, color = Color(0xFFBFA7FF), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                    if (project.status == ProjectStatus.PROCESSING || project.status == ProjectStatus.QUEUED) {
                        Text("${project.progress}%", color = LisanMuted, fontSize = 11.sp)
                    }
                }
            }
            Icon(Icons.Default.Folder, contentDescription = "فتح المشروع", tint = LisanCyan)
        }
    }
}
