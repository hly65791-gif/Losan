import importlib.util
import os

import pytest
from fastapi import HTTPException

ROOT = os.path.dirname(os.path.dirname(__file__))
spec = importlib.util.spec_from_file_location("lisan_backend", os.path.join(ROOT, "app", "main.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_ocr_overlay_validation_normalizes_fields():
    out = module._validate_ocr_overlays([{"start_ms": 10, "end_ms": 500, "text": "SALE", "x_percent": 25, "y_percent": 70}])
    assert out[0]["start_ms"] == 10
    assert out[0]["x_percent"] == 25.0


def test_ocr_overlay_validation_rejects_bad_timing():
    with pytest.raises(HTTPException) as exc:
        module._validate_ocr_overlays([{"start_ms": 500, "end_ms": 100, "text": "bad", "x_percent": 50, "y_percent": 50}])
    assert exc.value.status_code == 400


def test_alignment_rejects_empty_provider_segment(monkeypatch):
    class Resp:
        status_code = 200
        def json(self): return {"segments": [[]]}
    class Client:
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def post(self, *args, **kwargs): return Resp()
    monkeypatch.setenv("LISAN_ALIGNMENT_URL", "http://alignment.test")
    monkeypatch.setattr(module.httpx, "AsyncClient", lambda **kwargs: Client())
    import asyncio
    with pytest.raises(HTTPException) as exc:
        asyncio.run(module.align(module.AlignRequest(source_segments=[{"start_ms":0,"end_ms":1000,"text":"a"}], translated_segments=[{"start_ms":0,"end_ms":1000,"text":"ب"}])) )
    assert "EMPTY_SEGMENT" in str(exc.value.detail)


def test_alignment_rejects_unordered_words(monkeypatch):
    class Resp:
        status_code = 200
        def json(self): return {"segments": [[{"start_ms":500,"end_ms":700,"text":"one"},{"start_ms":400,"end_ms":600,"text":"two"}]]}
    class Client:
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def post(self, *args, **kwargs): return Resp()
    monkeypatch.setenv("LISAN_ALIGNMENT_URL", "http://alignment.test")
    monkeypatch.setattr(module.httpx, "AsyncClient", lambda **kwargs: Client())
    import asyncio
    with pytest.raises(HTTPException) as exc:
        asyncio.run(module.align(module.AlignRequest(source_segments=[{"start_ms":0,"end_ms":1000,"text":"a"}], translated_segments=[{"start_ms":0,"end_ms":1000,"text":"ب"}])) )
    assert "NOT_ORDERED" in str(exc.value.detail)


def test_alignment_accepts_valid_ordered_words(monkeypatch):
    class Resp:
        status_code = 200
        def json(self): return {"segments": [[{"start_ms":100,"end_ms":300,"text":"hello"},{"start_ms":300,"end_ms":600,"text":"world"}]]}
    class Client:
        async def __aenter__(self): return self
        async def __aexit__(self, *args): pass
        async def post(self, *args, **kwargs): return Resp()
    monkeypatch.setenv("LISAN_ALIGNMENT_URL", "http://alignment.test")
    monkeypatch.setattr(module.httpx, "AsyncClient", lambda **kwargs: Client())
    import asyncio
    result = asyncio.run(module.align(module.AlignRequest(source_segments=[{"start_ms":0,"end_ms":1000,"text":"a"}], translated_segments=[{"start_ms":0,"end_ms":1000,"text":"مرحبا بالعالم"}])) )
    assert len(result["segments"]) == 1
    assert result["segments"][0][1]["end_ms"] == 600
