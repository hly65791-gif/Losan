from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("lisan_backend", ROOT / "app" / "main.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def meta(duration=10.0, size=1000, width=1920, height=1080, audio=True):
    streams = [{"codec_type": "video", "width": width, "height": height}]
    if audio:
        streams.append({"codec_type": "audio"})
    return {"format": {"duration": str(duration), "size": str(size)}, "streams": streams}


def test_render_validation_valid_output(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    report = module._validate_render_output(meta(), meta(), out)
    assert report["valid"] is True
    assert all(report["checks"].values())


def test_render_validation_rejects_missing_video(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    output = meta()
    output["streams"] = [{"codec_type": "audio"}]
    report = module._validate_render_output(meta(), output, out)
    assert report["valid"] is False
    assert report["checks"]["video_stream"] is False


def test_render_validation_rejects_non_positive_duration(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    report = module._validate_render_output(meta(), meta(duration=0), out)
    assert report["valid"] is False
    assert report["checks"]["duration_positive"] is False


def test_render_validation_rejects_dimension_mismatch(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    report = module._validate_render_output(meta(), meta(width=1280, height=720), out)
    assert report["valid"] is False
    assert report["checks"]["dimensions_match"] is False


def test_render_validation_rejects_missing_audio_when_source_has_audio(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    report = module._validate_render_output(meta(audio=True), meta(audio=False), out)
    assert report["valid"] is False
    assert report["checks"]["audio_preserved"] is False


def test_render_validation_rejects_duration_drift(tmp_path):
    out = tmp_path / "out.mp4"
    out.write_bytes(b"x")
    report = module._validate_render_output(meta(duration=100), meta(duration=105), out)
    assert report["valid"] is False
    assert report["checks"]["duration_matches_source"] is False
