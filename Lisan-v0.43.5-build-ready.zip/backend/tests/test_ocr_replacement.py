import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("lisan_main", ROOT / "app" / "main.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_replacement_filter_uses_background_aware_delogo():
    f = module._build_ocr_replacement_filter([{
        "start_ms": 1000,
        "end_ms": 2500,
        "text": "SHOP",
        "x_percent": 50,
        "y_percent": 40,
        "width_percent": 20,
        "height_percent": 10,
        "enabled": True,
        "replace_original": True,
    }])
    assert "delogo=" in f
    assert "drawbox=" not in f
    assert "between(t,1.000,2.500)" in f


def test_replacement_filter_skips_disabled_or_non_replacement():
    f = module._build_ocr_replacement_filter([
        {"start_ms": 0, "end_ms": 1000, "enabled": False, "replace_original": True},
        {"start_ms": 0, "end_ms": 1000, "enabled": True, "replace_original": False},
    ])
    assert f == ""
