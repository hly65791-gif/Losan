from pathlib import Path
import json
import pytest

from app.main import _auto_track_ocr_overlay


def test_auto_tracking_follows_moving_template(tmp_path):
    cv2 = pytest.importorskip("cv2")
    import numpy as np
    video = tmp_path / "moving.mp4"
    w, h = 320, 180
    writer = cv2.VideoWriter(str(video), cv2.VideoWriter_fourcc(*"mp4v"), 10, (w, h))
    for i in range(20):
        frame = np.zeros((h, w, 3), dtype=np.uint8)
        x = 30 + i * 5
        cv2.rectangle(frame, (x, 70), (x + 60, 92), (255, 255, 255), -1)
        writer.write(frame)
    writer.release()
    item = {"start_ms": 0, "end_ms": 1900, "text": "SHOP", "x_percent": 18.75, "y_percent": 45, "width_percent": 18.75, "height_percent": 12.3}
    out = _auto_track_ocr_overlay(video, item, interval_ms=300, max_points=8)
    assert out["motion_tracking_enabled"] is True
    assert len(out["keyframes"]) >= 2
    assert out["keyframes"][-1]["x_percent"] > out["keyframes"][0]["x_percent"]
    assert out["tracking_method"] == "opencv_template_matching"


def test_auto_tracking_keeps_overlay_when_video_missing(tmp_path):
    item = {"start_ms": 0, "end_ms": 1000, "text": "X", "x_percent": 50, "y_percent": 50, "width_percent": 20, "height_percent": 10}
    out = _auto_track_ocr_overlay(tmp_path / "missing.mp4", item)
    assert out == item
