from pathlib import Path

from app import storage


def test_storage_key_is_stable():
    old = storage.PREFIX
    storage.PREFIX = "lisan"
    try:
        assert storage.key("uploads", "abc", "source.mp4") == "lisan/uploads/abc/source.mp4"
    finally:
        storage.PREFIX = old


def test_local_storage_is_ready_and_does_not_copy(tmp_path: Path):
    old = storage.BACKEND
    storage.BACKEND = "local"
    try:
        p = tmp_path / "x.bin"
        p.write_bytes(b"123")
        info = storage.put_file(p, "uploads/x/source.mp4")
        assert info["backend"] == "local"
        assert storage.enabled() is True
    finally:
        storage.BACKEND = old
