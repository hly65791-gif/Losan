# Lisan Release Gate — v0.43

Status: **BLOCKED**

## Evidence
- Backend tests: see generated test run for this snapshot.
- Android Gradle Wrapper: MISSING
- Android SDK: MISSING in current environment
- APK: NOT BUILT
- AAB: NOT BUILT
- Device install test: NOT RUN

## Required before READY
1. Add/restore Gradle Wrapper.
2. Install compatible JDK/Android SDK/Build Tools.
3. Run assembleRelease.
4. Run bundleRelease.
5. Verify APK/AAB signatures and metadata.
6. Install APK on a real/emulator device.
7. Run end-to-end Lisan flow.
