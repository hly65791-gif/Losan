# Lisan v0.35 — OCR Tracking Recovery

## What changed
- OCR motion tracking keeps the existing local template matcher.
- When confidence drops, the tracker periodically expands to a full-frame ORB re-detection.
- Reliable matches can update the template to adapt to lighting changes.
- Failed matches preserve the last reliable position instead of generating a false jump.
- Each keyframe stores confidence and tracking method.
- Aggregate `tracking_confidence` is stored on the OCR overlay.

## Safety
This remains visual tracking, not semantic OCR re-recognition or AI object tracking. A user can still edit keyframes manually.
