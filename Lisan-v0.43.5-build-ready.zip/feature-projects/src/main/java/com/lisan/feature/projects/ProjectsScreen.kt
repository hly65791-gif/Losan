package com.lisan.feature.projects

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.lisan.data.ProcessingWorker
import com.lisan.domain.model.Project
import com.lisan.domain.model.ProjectStatus
import com.lisan.domain.repository.ProjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.File
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Navy = Color(0xFF061126)
private val Surface = Color(0xFF0D1B38)
private val Surface2 = Color(0xFF12244A)
private val Purple = Color(0xFF8B4DFF)
private val Cyan = Color(0xFF12C8EE)
private val TextPrimary = Color(0xFFF7F8FF)
private val TextMuted = Color(0xFF9BA9C7)

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val repo: ProjectRepository
) : ViewModel() {
    val projects = repo.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun resume(project: Project, workManager: WorkManager) {
        viewModelScope.launch {
            repo.save(project.copy(status = ProjectStatus.QUEUED, error = null))
            val request = OneTimeWorkRequestBuilder<ProcessingWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .setInputData(workDataOf("projectId" to project.id, "sourceUri" to project.sourceUri))
                .build()
            workManager.enqueueUniqueWork("lisan_${project.id}", ExistingWorkPolicy.REPLACE, request)
        }
    }

    fun pause(project: Project, workManager: WorkManager) {
        workManager.cancelUniqueWork("lisan_${project.id}")
        viewModelScope.launch { repo.save(project.copy(status = ProjectStatus.PAUSED, updatedAt = java.time.Instant.now())) }
    }

    fun delete(project: Project, workManager: WorkManager) {
        workManager.cancelUniqueWork("lisan_${project.id}")
        viewModelScope.launch {
            repo.delete(project.id)
        }
    }
}

@Composable
fun ProjectsScreen(
    onBack: () -> Unit,
    onEditSubtitles: (String) -> Unit,
    onOpenVideo: (String) -> Unit = {},
    onCreateProject: () -> Unit = {},
    vm: ProjectsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val workManager = remember { WorkManager.getInstance(context) }
    val projects by vm.projects.collectAsState()
    var deleteTarget by remember { mutableStateOf<Project?>(null) }

    CompositionLocalProvider(androidx.compose.ui.unit.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = { Text("مشاريعي", fontWeight = FontWeight.ExtraBold) },
                    navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = TextPrimary, navigationIconContentColor = Cyan)
                )
            }
        ) { padding ->
            if (projects.isEmpty()) {
                EmptyProjects(onCreate = onCreateProject, modifier = Modifier.padding(padding))
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text("كل مشاريعك في مكان واحد", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 2.dp))
                    }
                    items(projects, key = { it.id }) { project ->
                        ProjectCard(
                            project = project,
                            subtitleReady = File(context.filesDir, "processing/${project.id}/translated.srt").exists(),
                            onResume = { vm.resume(project, workManager) },
                            onPause = { vm.pause(project, workManager) },
                            onEdit = { onEditSubtitles(project.id) },
                            onOpen = { project.outputPath?.let(onOpenVideo) },
                            onDelete = { deleteTarget = project }
                        )
                    }
                }
            }
        }
    }

    deleteTarget?.let { project ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("حذف المشروع؟") },
            text = { Text("سيتم حذف المشروع وملفاته المحلية. لا يمكن التراجع عن هذه العملية.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(project, workManager); deleteTarget = null }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ProjectCard(
    project: Project,
    subtitleReady: Boolean,
    onResume: () -> Unit,
    onPause: () -> Unit,
    onEdit: () -> Unit,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val progress = (project.progress / 100f).coerceIn(0f, 1f)
    val (statusText, statusColor, statusIcon) = when (project.status) {
        ProjectStatus.COMPLETED -> Triple("مكتمل", Color(0xFF36D399), Icons.Default.CheckCircle)
        ProjectStatus.PROCESSING -> Triple("جاري المعالجة", Cyan, Icons.Default.PlayArrow)
        ProjectStatus.QUEUED -> Triple("في الانتظار", Color(0xFFFFC857), Icons.Default.Schedule)
        ProjectStatus.PAUSED -> Triple("متوقف مؤقتًا", Color(0xFFFFC857), Icons.Default.Pause)
        ProjectStatus.FAILED -> Triple("فشل", Color(0xFFFF5C70), Icons.Default.Error)
        ProjectStatus.CANCELLED -> Triple("ملغى", TextMuted, Icons.Default.Error)
        ProjectStatus.DRAFT -> Triple("مسودة", TextMuted, Icons.Default.Edit)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                VideoThumbnail(project.sourceUri, Modifier.size(92.dp, 70.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(project.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                    Text("${project.sourceLanguage}  →  ${project.targetLanguage}", color = TextMuted, fontSize = 12.sp)
                    Surface(shape = RoundedCornerShape(50), color = statusColor.copy(alpha = .13f)) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(statusIcon, null, tint = statusColor, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(statusText, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "المزيد", tint = TextMuted) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("حذف المشروع") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menuOpen = false; onDelete() })
                    }
                }
            }

            if (project.status == ProjectStatus.PROCESSING || project.status == ProjectStatus.QUEUED || project.status == ProjectStatus.PAUSED) {
                Column(Modifier.padding(horizontal = 14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("التقدم", color = TextMuted, fontSize = 11.sp)
                        Text("${project.progress}%", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(5.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Purple, trackColor = Surface2)
                }
            }

            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    project.status == ProjectStatus.COMPLETED && project.outputPath != null -> {
                        Button(onClick = onOpen, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                            Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text("مشاهدة")
                        }
                        OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("تحرير") }
                    }
                    project.status == ProjectStatus.PROCESSING || project.status == ProjectStatus.QUEUED -> {
                        OutlinedButton(onClick = onPause, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Pause, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("إيقاف") }
                    }
                    project.status == ProjectStatus.PAUSED || project.status == ProjectStatus.FAILED -> {
                        Button(onClick = onResume, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Refresh, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("استئناف") }
                        if (subtitleReady) OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("تحرير") }
                    }
                    else -> {
                        OutlinedButton(onClick = onEdit, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Edit, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("فتح المشروع") }
                    }
                }
            }

            if (!project.error.isNullOrBlank()) {
                Text(project.error!!, color = Color(0xFFFF7B88), fontSize = 11.sp, modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp))
            }
        }
    }
}

@Composable
private fun VideoThumbnail(sourceUri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(sourceUri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(sourceUri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                MediaMetadataRetriever().use { retriever ->
                    retriever.setDataSource(context, Uri.parse(sourceUri))
                    retriever.getFrameAtTime(700_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }
            }.getOrNull()
        }
    }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Purple, Cyan))), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.VideoLibrary, null, tint = Color.White, modifier = Modifier.size(32.dp))
        Box(Modifier.align(Alignment.BottomEnd).padding(6.dp).size(25.dp).background(Color.Black.copy(alpha = .65f), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun EmptyProjects(onCreate: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(Navy).padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(86.dp).background(Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Folder, null, tint = Color.White, modifier = Modifier.size(42.dp))
            }
            Text("لا توجد مشاريع بعد", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("ابدأ بترجمة أول فيديو، وستظهر مشاريعك هنا مع كل تفاصيلها.", color = TextMuted, fontSize = 14.sp)
            Button(onClick = onCreate, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ابدأ ترجمة فيديو") }
        }
    }
}
