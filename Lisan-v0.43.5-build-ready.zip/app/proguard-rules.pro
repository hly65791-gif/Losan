# Lisan release rules
# Keep rules are added only when a verified shrinker issue requires them.
