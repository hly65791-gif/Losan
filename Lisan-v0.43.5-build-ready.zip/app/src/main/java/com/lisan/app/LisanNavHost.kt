package com.lisan.app

import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.compose.runtime.*
import androidx.navigation.compose.*
import com.lisan.feature.home.HomeScreen
import com.lisan.feature.projects.ProjectsScreen
import com.lisan.feature.settings.SettingsScreen
import com.lisan.feature.video.SubtitleEditorScreen
import com.lisan.feature.video.VideoPickerScreen

@Composable
fun LisanNavHost() {
    val nav = rememberNavController()
    var editorProjectId by remember { mutableStateOf<String?>(null) }
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(onTranslate = { nav.navigate("video") }, onProjects = { nav.navigate("projects") }, onSettings = { nav.navigate("settings") }) }
        composable("video") { VideoPickerScreen(onBack = { nav.popBackStack() }, onStarted = { nav.navigate("projects") { popUpTo("video") { inclusive = true } } }) }
        composable("projects") {
            val context = androidx.compose.ui.platform.LocalContext.current
            ProjectsScreen(
                onBack = { nav.popBackStack() },
                onCreateProject = { nav.navigate("video") },
                onEditSubtitles = { id -> editorProjectId = id; nav.navigate("subtitle-editor") },
                onOpenVideo = { path ->
                    runCatching {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", java.io.File(path))
                        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "video/mp4")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        })
                    }
                }
            )
        }
        composable("subtitle-editor") { val id = editorProjectId; if (id != null) SubtitleEditorScreen(projectId = id, onBack = { nav.popBackStack() }) else nav.popBackStack() }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}
