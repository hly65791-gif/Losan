# Changelog

## 3.9.0
- Added Background Processing & Notification Gate.
- Requires start/resume/completion/failure notifications for long-running media jobs.
- Requires Android foreground-worker support for long video processing.
- Requires network-loss retry/resume behavior and persisted resumable-upload state.
- Requires manual pause/resume UX where appropriate.

# CHANGELOG

## 3.7.0
- Added Reference-Driven Media Rendering Gate.
- Added explicit visual requirements and verification rules for subtitle burn-in.

## 3.6.0
- Added Production Media Delivery System.

## 3.8.0
- Added subtitle preset persistence/render propagation checks.
- Added media delivery cleanup gate.
- Added valid JSON transcript artifact requirement.
