# App Builder Skill v3.7

AI-assisted application engineering skill for inspecting, planning, implementing, testing, debugging, building, packaging and releasing applications.

Includes:
- architecture and project-state management
- Gradle Wrapper/Gradle toolchain management
- Build Doctor and Dependency Doctor
- Android/JDK/SDK checks
- tests, lint and artifact verification
- release gates
- backend/API/media processing guidance
- reference-driven media rendering and subtitle style verification
- large-file and resumable-processing rules
- Lisan production pipeline profile

Core rule: never claim a build, test, APK, API, or release succeeded unless it was actually executed and verified.
