# App Builder Skill v3.11

Production-oriented Android app builder workflow with Gradle/toolchain diagnostics, testing, artifact verification, video-processing gates, subtitle editor review gates, and professional subtitle timeline controls.

Core workflow:
`INSPECT → SNAPSHOT → TOOLCHAIN DOCTOR → PLAN → IMPLEMENT → FORMAT → UNIT TEST → BUILD → LINT → PACKAGE → ARTIFACT VERIFY → RELEASE GATE`

Video workflow:
`TRANSLATE → SRT/VTT → PREVIEW → TIMELINE EDIT → STYLE/POSITION → UNDO/REDO → RENDER → VALIDATE → DOWNLOAD → COMPLETED`
