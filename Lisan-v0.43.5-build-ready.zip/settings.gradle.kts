pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Lisan"
include(":app")
include(":core-common")
include(":core-ui")
include(":domain")
include(":data")
include(":feature-home")
include(":feature-video")
include(":feature-projects")
include(":feature-settings")
