# Lisan v0.39 — Projects UI

## Implemented
- Professional RTL dark projects screen matching the Lisan visual identity.
- Real Room-backed project list with live state updates.
- Video thumbnails extracted from source URI using MediaMetadataRetriever.
- Status chips for completed, processing, queued, paused, failed, cancelled, draft.
- Progress bar with percentage for active jobs.
- Actions: pause, resume, edit subtitles, watch completed output, delete.
- Delete confirmation dialog.
- Empty state with direct path to video selection.
- Completed video opening through Android FileProvider with read-only URI grant.
- Safe provider paths limited to app files/cache.
- Android app versionName bumped to 0.39.0.

## Verification
- Backend pytest: 48 passed.
- Android Gradle compile was not run because the project does not include a Gradle wrapper in this environment.
