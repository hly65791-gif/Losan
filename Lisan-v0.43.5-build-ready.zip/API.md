# Lisan Backend API

## Health
`GET /health`

## Resumable upload
- `POST /v1/uploads/init` — creates an upload session.
- `GET /v1/uploads/{upload_id}` — returns current byte offset.
- `PUT /v1/uploads/{upload_id}` — appends a chunk using `X-Chunk-Offset` and `X-Total-Size`.
- `POST /v1/uploads/{upload_id}/complete` — finalizes the upload.
- `DELETE /v1/uploads/{upload_id}` — removes a completed/temporary source upload.

## Rendering
`POST /v1/render-upload` multipart fields:
- `upload_id`
- `subtitles`
- `style` (`LISAN_CLASSIC`, `CLEAN`, `LARGE`)

The endpoint stores the MP4 under an artifact ID and returns metadata.

## Artifact
- `GET /v1/artifacts/{artifact_id}` — metadata.
- `GET /v1/artifacts/{artifact_id}/download` — streamed MP4 download.

## Subtitle style
`LISAN_CLASSIC` is the default reference-matched style: bold white Arabic, black outline, subtle shadow, bottom-center, Noto Sans Arabic, with source geometry preserved.

### Subtitle appearance fields
Optional render fields on `/v1/render-upload` and `/v1/render`:
- `font_size` — 24..110
- `position` — `TOP`, `CENTER`, `BOTTOM`, or `CUSTOM`
- `shape` — `OUTLINE`, `SHADOW`, `BOX`, `ROUNDED_BOX`
- `outline_width` — 0..12
- `shadow_depth` — 0..8
- `horizontal_percent` — clamped to 8..92
- `vertical_percent` — clamped to 8..92

Custom coordinates map to the ASS `PlayResX=1920`, `PlayResY=1080` canvas. Preset positions override coordinates with safe defaults.

## Object storage
- `GET /v1/storage/status` — storage backend readiness.
- `GET /v1/artifacts/{artifact_id}/download-url?expires_seconds=900` — short-lived signed URL when GCS/S3 is configured.
