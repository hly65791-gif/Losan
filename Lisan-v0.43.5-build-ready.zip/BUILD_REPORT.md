# Lisan v0.43.1 Build Report

## Inspection environment
- Java: OpenJDK 21.0.11
- System Gradle: NOT FOUND
- Android SDK: NOT FOUND
- ADB: NOT FOUND
- FFmpeg: AVAILABLE
- ffprobe: AVAILABLE
- Gradle Wrapper in archive: MISSING

## Backend validation
- Python compileall: PASS
- Pytest: 48 passed, 12 warnings
- Warnings are FastAPI `on_event` deprecation warnings; they do not fail the test run.

## Android validation
- Gradle build: BLOCKED
- Lint: BLOCKED
- APK: NOT BUILT
- AAB: NOT BUILT

## Release status
BLOCKED — Android toolchain/artifact validation is still required.

## v0.43.4 cloud bootstrap
- Gradle 8.10.2 bootstrap: added.
- Gradle distribution SHA-256 verification: configured.
- Standard `gradle-wrapper.jar`: still not generated in this environment because Gradle itself is unavailable and the official binary cannot be downloaded from this execution environment.

## v0.43.5 cloud wrapper
- Added a build-service-compatible `gradle/wrapper/gradle-wrapper.jar` bootstrap.
- The bootstrap verifies the pinned Gradle 8.10.2 distribution checksum before extraction.
- Note: this JAR is a temporary Lisan bootstrap, not the official Gradle Wrapper JAR.


## Local verification (2026-10-05)
- Gradle Wrapper: PASS (wrapper JAR integrity verified)
- Project structure: PASS
- Android manifests/XML: PASS (17 XML files parsed)
- Backend Python syntax: PASS
- APK/AAB present in source archive: NO
- Local Gradle build: BLOCKED by environment network resolution (`services.gradle.org` unavailable), not by a confirmed Gradle compilation error.
- Cloud build workflow: `.github/workflows/android-build.yml` present and configured for JDK 17 / Gradle 8.10.2 / debug APK artifact.
