# Lisan Object Storage

v0.27 adds a production storage abstraction.

## Modes
- `LISAN_STORAGE_BACKEND=local`: development; files stay on the worker disk.
- `gcs`: Google Cloud Storage; completed uploads and rendered artifacts are promoted to the bucket.
- `s3`: Amazon S3 or an S3-compatible service; same object layout.

## Object layout
- `lisan/uploads/<upload_id>/source.<ext>`
- `lisan/artifacts/<artifact_id>/translated_video.mp4`

Workers can reconstruct a missing local source from object storage, which is important when multiple workers do not share a filesystem.

## Production rules
1. Use a private bucket.
2. Give the backend only the minimum object permissions it needs.
3. Keep signed download URLs short-lived (the storage adapter defaults to 15 minutes).
4. Configure lifecycle rules to delete abandoned uploads and old artifacts.
5. Do not put cloud credentials in the Android app.

The current resumable HTTP upload remains available; object storage promotion happens after the upload is complete. A future optimization can move chunk reception directly to provider multipart/resumable APIs.

## Retention cleanup (v0.28)
Lisan now has a safety-first retention sweep. It protects uploads and artifacts referenced by active jobs, removes abandoned incomplete uploads, and removes old completed artifacts. When object storage is enabled, the artifact's object is deleted only after the local artifact is stale and unreferenced; cloud deletion failures leave the local metadata for a later retry.

Environment variables:
- `LISAN_INCOMPLETE_UPLOAD_RETENTION_DAYS=1`
- `LISAN_UPLOAD_RETENTION_DAYS=2`
- `LISAN_ARTIFACT_RETENTION_DAYS=30`
- `LISAN_CLEANUP_INTERVAL_SECONDS=21600` (6 hours; set `0` to disable)
