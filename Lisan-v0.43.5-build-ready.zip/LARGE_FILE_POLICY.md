# Lisan Large-File Processing Policy — v0.23

- Uploads are streamed to disk in 1 MiB chunks; they are not loaded as one in-memory byte array.
- Default input limit is 8 GiB and can be changed with `LISAN_MAX_INPUT_BYTES`.
- Resumable upload chunks are checked against the declared total size before appending.
- OCR samples frames at a configurable rate and caps total extracted frames (`LISAN_OCR_MAX_FRAMES`, default 6000).
- OCR frame files live in a temporary directory and are removed automatically after the request.
- STT receives a disk-backed media path; the upload itself is streamed. Whisper model memory remains provider-dependent.
- Subtitle files are capped at 64 MiB on render endpoints.
- For very large deployments, configure a dedicated worker/queue and object storage rather than running expensive STT/OCR in the API process.
